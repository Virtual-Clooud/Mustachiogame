---
share: true
---
Pitch:
Arma é dividida em partes cada parte pode ser modificado para ser imbuida com skills

# Sumário:

Um jogo topdown de ação !necessário algo que o torne único em relação a todos os outros jogos parecidos com ele!

Gameplay:

Habilidades passivas e ativas que provém de itens específicos. jogo se passa no velho oeste, gameplay em torno de armas e combate a tiros.

Gameplay 1: arma que possui tiro primário e secundário, jogador pode pegar itens armas alternativas de acordo com a progressão

Pilares:

Player:
Bigodes de chefes: Possuem habilidades que auxiliam no jogador
Itens passivos: Tipo cuphead 
Flow: Mapa aberto -> jogador entra em dungeon -> faz dungeon -> Boss -> Consegue ultimate -> Passa pra próxima dungeon -> Se quiser faze dungeon faz pega itens que não tinha mas não pega recompensa de chefe 
Combate -> Upgrade -> Atividade terciária que reforça a primeira

# Player:

  
## Atributo de arma
## Ultimate
## 2 itens: Passivos, Condicionais, ativos
## Armas: Revólver, fuzil, metralhadoras, submetralhadoras, pistolas, escopetas, granadas 

Equipamento: tônicos, bigodes temporários, munições

Revólver: Tiro primário, preciso de dano médio se ricochetear de uma parede e acertar um inimigo aplica efeito “marcado”

Tiro secundário rajada de tiros rápida, caso exista um inimigo marcado por perto todos os vão em direção á esse inimigo
# Tiros:
- tiro que destroem/nulificam ataques
- tiro que aplicas posion
- tiro Penetrantes
- tiro que aplicam maldição, se jogador aplicar x de dano em período fazer inimigo explodir

  

# Unique Features


# MVP

uns 5 boss com diferentes tipos de bigodes que o jogador coleta até chegar aos boss ele precisa enfrentar arena com inimigos

  

# Story

Em um mundo no Velho Oeste(1602), onde a sociedade é dividida por castas sociais por meio do tamanho do bigode, o protagonista nasce sem bigode, tendo seu pai, uma figura importante como o rei de uma terra não tão distante com o bigode avantajado, o protagonista cresce e em um determinado dia, ele acaba morrendo, quando chega no paraíso dos bigodudos ele é barrado por não ter bigode; e por isso é jogado ao purgatório, porém também não é aceito e é jogado de volta à terra, com isso ele  decide que vai atrás de um modo de conseguir um bigode para que ele possa ser mais respeitado. Na busca de um bigode, ele conhece uma bruxa também sem bigode que lhe faz uma proposta, se ele coletar os bigodes primordiais que são posses dos Bosses, a bruxa conseguira fazer um bigode para o protagonista, então ele começa sua jornada para matar e conquistar todos os bigodes que ele precisava para concluir seu plano. Depois de um determinado tempo, ele volta com todos os bigodes necessários e entrega para a bruxa que cria o bigode supremo e revela para o protagonista que ela tinha um bigode, porém o pai(o rei), roubou o da bruxa para usar, a bruxa também revela que de cada 100 anos, nasce uma pessoa sem bigode; e o pai do protagonista era essa pessoa, e que essa condição era hereditária, e o rei que também é o pai do protagonista roubou o bigode da bruxa a fim de aumentar seu status e garantir uma boa vida. Depois disso a bruxa pega o bigode supremo e coloca em si mesma pra ter sua vingança e acabar com o Oeste e o reino, nisso o protagonista acha forças para enfrentar a bruxa e tomar o bigode supremo, assim concluindo seu objetivo, e se tornado o bigodudo mais importante.

## Characters

Principais: 

Protagonista - Billy 

Pai do protagonista(o Rei) - 

Bruxa -

Xerifes - 

Médicos - 

Bosses - Mexicano: Machete(Mercenário), Chinês: Li Yi(Fortaleza Prateada), Russo: Ivan Boris(General), 

## Ambiente:

Velho oeste com toque de magia

## Narrative

# Gameplay

## Design Pillars

## Core Loop

Os verbos que o jogador pode fazer

Derrotar inimigos

Comprar armas melhores

Melhorar seus equipamentos: Armadura, inventário, habilidades etc

## Mechanics

Efeitos de status: Inimigos podem sofrer status por habilidades e armas do jogador

Level-up: Jogador compra e melhora as capacidades de seu personagem e suas armas

## Dynamics

Inimigos variados e bosses

# Levels

## Level Progression

Enfrentar um monte de arenas com armadilhas e inimigos até chegar no boss

## Bosses

Donos dos bigodes

## Final Boss:

Bruxa

# Art

Sei lá, por enquanto assets como placeholder

## Summary

## Environments

# UI, Systems & Options

## UI

## Systems

## Options & Controls

# Audio

## Summary

# Dev Plan:

  
