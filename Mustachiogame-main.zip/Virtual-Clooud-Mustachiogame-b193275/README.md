---
share: true
---

# Mustachio Game
	Um jogo que pode acabar em processo :)
# Flow:
Jogador começa em uma área central que possue conexões para as outras áreas perigosas do mundo ao redor.
## Dungeons:
## Boss:
Únicos para cada área, ao eliminá-los o jogador pega seus bigodes que o dá uma habilidade que o auxilia no combate
# Jogador:
Jogador possue três vidas que não se recuperam rápido, possue Dash para facilitar movimentação
## Armas:
4 armas que possuem 1 tiro primário e secundário
Cada arma encorajada 1 tipo de gameplay diferente























