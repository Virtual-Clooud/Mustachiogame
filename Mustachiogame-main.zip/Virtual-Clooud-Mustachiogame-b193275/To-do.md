---
share: true
---
# 4 boss
	Quin Shihuang
	Machete
	Ivan IV.II
	Theozin
# 4 atributos

# 4 área
	
# 4 arma 
